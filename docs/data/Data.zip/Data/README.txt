
///////////////////////////////////////////
//////////   README - Datasets   //////////
///////////////////////////////////////////

The folder called "IMDb" contains the two files used for making the network, i.e. movie titles and actors/actresses for movies. 

The folder called "Plot Summaries" contains the files used for making word clouds and sentiment analysis. "plot_summaries.txt" contains the summaries for old movies and "TMDBSummareis.txt" contains summaries for new movies. 



tMDb API source: https://www.themoviedb.org/documentation/api

IMDb datasets: https://www.imdb.com/interfaces/